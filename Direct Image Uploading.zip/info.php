<?php
$ext_info = array(
	'title'			=> 'Direct Image Uploading',
	'website'		=> 'http://futurebb.futuresight.org/extensions/directimageuploading',
	'support'		=> 'http://futuresight.org/support',
	'uninstallable'	=> true,
	'minversion' 	=> 1.4
);